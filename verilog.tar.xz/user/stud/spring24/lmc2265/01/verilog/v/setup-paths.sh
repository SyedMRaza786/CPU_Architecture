export PATH=$PATH:/homes/user/fac/tk3070/tmp/riscv-gcc/riscv-32/bin/:/homes/user/fac/tk3070/tmp/elf2hex-build/bin/
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/homes/user/fac/tk3070/tmp/test/csee4824-project-3-main/tmp
