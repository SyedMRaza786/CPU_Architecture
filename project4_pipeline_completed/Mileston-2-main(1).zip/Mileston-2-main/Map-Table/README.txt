This folder contains the makefile, testbench, and module for the maptable. This map table is 2 wide superscalar.
